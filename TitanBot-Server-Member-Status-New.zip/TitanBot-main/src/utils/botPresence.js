/**
 * Keep Discord's visible activity in sync with this bot's guild/member totals.
 * Member totals are summed from each guild's reported memberCount; a user in
 * multiple guilds is counted once per guild.
 */
export async function updateBotPresence(client) {
  if (!client?.user || !client?.guilds?.cache) return;

  const guilds = client.guilds.cache;
  const totalServers = guilds.size;
  const totalMembers = guilds.reduce((sum, guild) => {
    const count = Number(guild.memberCount);
    return sum + (Number.isFinite(count) && count > 0 ? count : 0);
  }, 0);

  const activityName = `${totalMembers.toLocaleString("en-US")} Members | ${totalServers.toLocaleString("en-US")} Servers`;

  try {
    await client.user.setPresence({
      status: client.config?.bot?.presence?.status || "dnd",
      activities: [{ name: activityName, type: 3 }], // Watching
    });
  } catch (error) {
    // Presence failures should not crash the bot or stop later refreshes.
    client.logger?.warn?.("Could not update bot presence:", error);
  }
}
